%
% file:      	surf2solid_ex.m, (c) Matthew Roughan, Wed Mar  9 2011
% directory:   /home/mroughan/src/matlab/STL/
% created: 	Wed Mar  9 2011 
% author:  	Matthew Roughan 
% email:   	matthew.roughan@adelaide.edu.au
% 
% Examples of converting a surface to a solid for printing
%
clear all; 
close all;
%%
SCALE = 1e-04;
Nx = 128; Ny = 128;          % grid numbers ,
NNNN = 100;
Lx = NNNN.*SCALE; Ly = NNNN.*SCALE;          % domain lengths m
DX = Lx./(Nx-1).*(0:Nx-1);
DY = Ly./(Ny-1).*(0:Ny-1);
[XX,YY]=meshgrid(DX,DY);
X = XX(3:end-2,3:end-2);
Y = YY(3:end-2,3:end-2);
ZZ=1*load('S2N-0.0018-08-02.txt');

[H1,L1] = find(ZZ == max(max(ZZ)));
LH1 = length(H1);
LL1 = length(L1);
INDH = round(LH1/2);
INDL = round(LH1/2);
DSS = (H1-H1(INDH)).^2+(L1-L1(INDH)).^2;
DSSM = max(max(DSS));
for II = 1:LH1
    if II == INDH
        ZZ(H1(II),L1(II)) = max(max(ZZ));
    else
        ZZ(H1(II),L1(II)) = max(max(ZZ))-((H1(II)-H1(INDH)).^2+(L1(II)-L1(INDH)).^2)./DSSM.*0.001.*max(max(ZZ));
    end
end
[H2,L2] = find(ZZ == max(max(ZZ)));
% Z = zeros(Ny,Nx);
% %Z = max(max(ZZ)).*ones(Ny,Nx);
% for IR = 2:Ny
%     DXXX = sqrt((Ny/2).^2-(Ny/2-IR).^2);
%     Z(IR,max(1,floor(Nx/2-DXXX)):max(1,floor(Nx/2+DXXX))) = ZZ(IR,max(1,floor(Nx/2-DXXX)):max(1,floor(Nx/2+DXXX)));   
% end

% 
Z = ZZ(3:end-2,3:end-2);
% Z = ZZ;
% Z(1,:) = 1.00.*max(max(ZZ));
% Z(end,:) = 1.00.*max(max(ZZ));
% Z(:,1) = 1.00.*max(max(ZZ));
% Z(:,end) = 1.00.*max(max(ZZ));

% ZZ = Z;
% ZZ(1:2,:) = 0;
% ZZ((end-1):end,:) = 0;
% ZZ(:,1:2) = 0;
% ZZ(:,(end-1):end) = 0;
% XX = X;
% XX(1,:) = 0;
% XX(end,:) = 0;
% XX(:,1) = 0;
% XX(:,end) = 0;
% YY = Y;
% YY(1,:) = 0;
% YY(end,:) = 0;
% YY(:,1) = 0;
% YY(:,end) = 0;
% do the "peaks" function from Matlab
%%
% [X,Y] = meshgrid(-3:.125:3);
% Z = peaks(X,Y) / 3;
%%

% convert to a solid
[X_out, Y_out, Z_out] = surf2solid3(X, Y, Z, 1, 1e-03);
print('-dpng', 'surf2solid_ex.png');

% output a STL version of the solid
filename = 'surf2solid_ex1.stl';
mode = 'binary';
surf2stl(filename,X_out,Y_out,Z_out,mode);
%surf2stl(filename,XX,YY,ZZ,mode);

% do Gary's surface
% clear;
% d = 0.05;
% x = -1:d:1;
% y = -1:d:1;
% [X,Y] = meshgrid(x, y);
% 
% theta = atan2(Y, X);
% r = sqrt( X.^2 + Y.^2 );
% 
% Z = r .* sin( 3*theta ) / 3;
% 
% % create a surface from the function
% [X_out, Y_out, Z_out] = surf2solid(X, Y, Z);
% print('-dpng', 'garys_surface.png');
% 
% % now output the surface
% filename = 'garys_surface.stl';
% mode = 'binary';
% surf2stl(filename,X_out,Y_out,Z_out,mode)

