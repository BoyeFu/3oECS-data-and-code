function [theta_out, r_out, z_out, x_out, y_out] = surf2solid_polar(theta, r, z, S, delta)
%
% file:      	surf2solid.m, (c) Matthew Roughan, Mon Feb 14 2011
% directory:   /home/mroughan/src/matlab/STL/
% created: 	Mon Feb 14 2011 
% author:  	Matthew Roughan 
% email:   	matthew.roughan@adelaide.edu.au
% 
% Convert a surface into a solid object for printing on a 3D printer
%  
%    assumes that the surface is given in polar coordinates
%
% The assumption is that 
%     -- the surface is a function z(theta, r)
%     -- theta: is a 1xn  vector running from [0-2*pi] (including end so the surface is closed)
%                theta should be increasing
%     -- r: is a mxn array giving the radii at each of the angles theta
%                r shold be increasing
%     -- z is given as a function of (theta, r), and is mxn matrix
%  
% The output will  be a solid with height given by z at each point (x,y), and
%     -- the surface z will be shifted by z_0, such that z+z_0 >= delta
%        where delta is the minimum z height
%     -- centering is assumed to be at r=0
%     -- the x, y, and z values will be scaled so that the largest value of
%                (max(x) - min(x), (max(y)-min(y)), and 2*(max(z)-min(z))
%        is such that the largest of these dimensions is size S where S in measured in mm
%          (NB: matlab co-ordinates come out roughly as mm in the makerbot)
%     -- the surface z(x,y)+z_0 will have vertical walls going down to the (x,y) plane,
%        and the bottom surface of the object will be the part of the (x,y) plane including
%        the (x,y) points of the input (suitable rescaled)
%                  (e.g. see what meshz does)
%
% NB: fair bit of code is inspired by meshz
%

err_id = 'surf2solid_polar:InvalidInput';

% check inputs
if (nargin < 3)
  error(err_id,'Need to input at least 3 arguments.')
end
if ischar(theta) || ischar(r) || ischar(z)
  error(err_id,'Input should not be characters.')
end
[m,n] = size(z);
[mr,nr] = size(r);
[m_theta,n_theta] = size(theta);
if (m == 1 || n == 1)
  error(err_id,'z must have size >1 in each direction.')
end
if (~isequal(size(z),size(r)))
  error(err_id,'Input arrays r and z should all be the same size.')
end
if (m_theta ~= 1 | n_theta ~= n)
  error(err_id,'Theta should be 1xn')
end
if (~all(isfinite(z)))
  error(err_id,'z must have finite values.')
end
if (~all(isfinite(r)) | any(r < 0))
  error(err_id,'r must have finite, non-negative values.')
end
if (~all(isfinite(theta)))
  error(err_id,'theta must have finite values.')
end
if (any(theta < 0) | any(theta > 2*pi))
  error(err_id,'theta must run between [0-2*pi]')
end
if (nargin < 4)
  S = 40; % make the default max length along an axis 40mm
end
if (S>100)
  error(err_id,'S must be <= 100 due to size of build platform')
end
if (nargin < 5)
  delta = 3; % make the default minimum height 3 mm 
end
if (delta < 0)
  error(err_id,'delta must be >=0 to build')
end

% scale co-ordinates
theta_out = repmat(theta, m, 1);
x = r.*cos(theta_out);
y = r.*sin(theta_out);
x_diff = max(max(x)) - min(min(x));
y_diff = max(max(y)) - min(min(y));
z_diff = 2*(max(max(z)) - min(min(z)));
max_diff = max([x_diff; y_diff; z_diff]);
scale_factor = S/max_diff
r = scale_factor * r;
z_s = scale_factor * z;

% shift the min z co-ordinate
mn_z = min(min(z_s));
z = z_s + delta - mn_z;

x = r.*cos(theta_out);
y = r.*sin(theta_out);
xmin = min(min(x));
ymin = min(min(y));
xmax = max(max(x));
ymax = max(max(y));

% add a starting row of r=0 points, assuming z is defined for this
k = find(abs(r) < 1.0e-4);
z0 = z(k(1));
z_out = [z0*ones(1,n);
	 z;
	];
r_out = [zeros(1,n);
	 r;
	];
theta_out = [theta;
	     theta_out;
	    ];

% repeat the final set of r's, but at height zero
z_out = [z_out;
	 zeros(1,n);];
r_out = [r_out;
	 r(m,:);
	];
theta_out = [theta_out;
	     theta;
	    ];

% add in the final point at (0,0)
z_out = [z_out;
	 zeros(1,n);];
r_out = [r_out;
	 zeros(1,n);
	];
theta_out = [theta_out;
	     theta;
	    ];


x_out = r_out .* cos(theta_out);
y_out = r_out .* sin(theta_out);
z_out = z_out;
mesh(x_out, y_out, z_out);

