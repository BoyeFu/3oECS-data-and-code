%
% file:      	surf2solid_polar_ex.m, (c) Matthew Roughan, Wed Mar  9 2011
% directory:   /home/mroughan/src/matlab/STL/
% created: 	Wed Mar  9 2011 
% author:  	Matthew Roughan 
% email:   	matthew.roughan@adelaide.edu.au
% 
% convert a surface in polar form, to a solid, suitable for export as STL
%
%

% plot a Gaussian distribution
% n = 24;
% dp = 2*pi/(n-1);
% theta = 0:dp:2*pi;
% 
% m = 30;
% r = repmat([0:m-1]', 1, n);
% z = 10*exp( -r.^2 / 100 );
% 
% % convert to a solid
% [theta_out, r_out, Z_out, X_out, Y_out] = surf2solid_polar(theta, r, z);
% %print('-dpng', 'Plots/surf2solid_polar_ex.fig');
% 
% % output a STL version of the solid
% filename = 'surf2solid_polar_ex.stl';
% mode = 'binary';
% surf2stl(filename,X_out,Y_out,Z_out,mode);
clear all
close all
SCALE = 1e-04;
Nx = 128; Ny = 128;          % grid numbers ,
NNNN = 100;
Lx = NNNN.*SCALE; Ly = NNNN.*SCALE;          % domain lengths m
DX = Lx./(Nx-1).*(-Nx/2:Nx-Nx/2);
DY = Ly./(Ny-1).*(-Ny-2:Ny-Ny/2);


% % do Gary's surface on cylinder
ZZ = load('S2N-0.0009.txt');
% ZZ2 = load('SUFANumber_2_Pressure0_Exp1.000000e+02_Var2.500000e-05.txt');
% ZZZ = ZZ-ZZ2;
% max(max(ZZZ))
%%
dp = 2*pi/(Nx-1);
theta = 0:dp:2*pi;

m = 128;
RR = 0:0.005/(Nx-1):0.005;
r = repmat(RR', 1, Nx);
z = zeros(Ny,Nx);
for II = 1:Nx
    for JJ = 1:Ny
       RRR = sqrt(DX(II).^2+DY(JJ).^2);%The distance between point to original point
       DRR = abs(RR-RRR);%To find the r place
       DRRMIN = min(min(DRR));%the minmum value of difeerence;
       H1 = find(DRR==DRRMIN);
       NR = H1(1);%The place of the z
       if (DX(II)>=0)&&(DY(JJ)>=0)
           ThetaR = asin(DY(JJ)./RRR);%The real theta of the data
       elseif (DX(II)<0)&&(DY(JJ)>=0)
           ThetaR = acos(DX(II)./RRR);
       elseif (DX(II)<0)&&(DY(JJ)<0)
           ThetaR = 2*pi-acos(DX(II)./RRR);
       elseif (DX(II)>=0)&&(DY(JJ)<0)
           ThetaR = 2*pi+asin(DY(JJ)./RRR);
       end
           DThetaR = abs(theta-ThetaR);%To find the theta place
           DThetarMIN = min(min(DThetaR));
           H2 = find(DThetaR==DThetarMIN);
           NT = H2(1);%The place for theta
     z(NR,NT) = ZZ(JJ,II);
    end
end
%z((end-1):end,:) = max(max(z));
%z = r .* sin(3*repmat(theta,m,1))/3;

% convert to a solid
[theta_out, r_out, Z_out, X_out, Y_out] = surf2solid_polar02(theta, r, z, 20, -min(min(z)));
print('-dpng', 'garys_surface_polar.png');


% output a STL version of the solid
filename = 'garys_surface_polar.stl';
mode = 'binary';
surf2stl(filename,X_out,Y_out,Z_out,mode);
figure(2)
mesh(X_out, Y_out, Z_out);


% do an example on an irregular region
% clear;
% n = 37;
% dp = 2*pi/(n-1);
% theta = 0:dp:2*pi;
% 
% m = 30;
% r = [0:m]' * (cos(3*theta)+2);
% 
% z = ones(size(r));
% 
% % convert to a solid
% [theta_out, r_out, Z_out, X_out, Y_out] = surf2solid_polar(theta, r, z, 20, 5);
% print('-dpng', 'surf2solid_polar_ex_2.png');
% 
% 
% % output a STL version of the solid
% filename = 'surf2solid_polar_ex_2.stl';
% mode = 'binary';
% surf2stl(filename,X_out,Y_out,Z_out,mode);


