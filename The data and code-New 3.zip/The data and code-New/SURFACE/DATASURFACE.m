%%
clear
%%
Nx = 128; Ny = 128;          % grid numbers ,
NNNN = 100;
SCALE = 1e-04;
Lx = NNNN.*SCALE; Ly = NNNN.*SCALE;          % domain lengths m
DX = Lx./Nx.*(1:Nx);
DY = Ly./Ny.*(1:Ny);
[DDX, DDY] = meshgrid(DX,DY);
S20009 = 100.*load('S2N-0.0009.txt');
S20012 = load('S2N-0.0012.txt');
S20009(1,:) = max(max(S20009));
S20009(end,:) = max(max(S20009));
S20009(:,1) = max(max(S20009));
S20009(:,end) = max(max(S20009));
S20015 = load('S2N-0.0015.txt');
S20018 = load('S2N-0.0018.txt');
S20009SD = std(S20009,0,'all');%SSD
S20012SD = std(S20012,0,'all');%SSD
S20015SD = std(S20015,0,'all');%SSD
S20018SD = std(S20018,0,'all');%SSD
figure(1)
surf(DDX/1e-02,DDY/1e-02,S20009)
% hold on
% surf(DDX,DDY,max(max(S20012)).*ones(Nx,Ny))
% hold on
% surf(DDX,DDY,SURF009P00UP./1e-06)
xlabel('Length (cm)')
ylabel('Length (cm)')
zlabel('Height (cm)')