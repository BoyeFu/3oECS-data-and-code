%Do analysis of the experiment data
clear all
SS2 = load('S2real.txt');
LL = max(max(SS2));
MU = [1.34E-01	1.34E-01	1.34E-01	1.36E-01	1.38E-01	1.45E-01	1.48E-01	1.49E-01	1.50E-01	1.54E-01	1.56E-01];
E = [0.000388661	0.000390925	0.000393192	0.000619574	0.000807361	0.001516038	0.00303822	0.0054532	0.010173948	0.01752067	0.028883523];
PM = MU.*(4.*MU-E)./(3.*MU-E);
Pre = [0.00389896	0.007781487	0.011647555	0.017689324	0.025494906	0.040076071	0.069322932	0.122231239	0.223412183	0.40455444	0.718731414];
figure(1)
plot(Pre,MU)
hold on
plot(Pre,PM);
xlabel('Pressure (MPa)')
ylabel('Elastic modulus')
legend('Shear modulus','P-wave modulus')
