% from fx, fy, vx, vy construct 'node_xy', 'node_connectivity', 'N', 'neighwithpositiveflux', 'PositiveFluxVector', 'link_Ttime'
%I will read again
function [node_xy, neighwithpositiveflux, PositiveFluxVector, link_Ttime, node_connectivity] = transport_param_gen(Nx, Ny, fname_flow, fname_Qtot)
% Load information from flow solver
load(fname_flow);%The flow in flow solver
load(fname_Qtot);%The Qtot in flow solver

%%% node_connectivity %%%
[n, m] = size(Qtot);
I_size = m*n;

% 1-off diagonal elements
V = repmat([ones(m-1,1); 0],n,1);%[ones(m-1,1); 0]It is a line, make it as n line, it is matrix n*m
V = V(1:end-1);         % remove last zero in one line

% n-off diagonal elements
U = ones(m*(n-1),1);

% get the upper triangular part of the matrix
node_connectivity = sparse(1:(I_size-1),    2:I_size, V, I_size, I_size) + sparse(1:(I_size-m),(m+1):I_size, U, I_size, I_size);
%1:(I_size-1) it has m*n element the upper triangular part of the matrix (i>j)
% finally make node_connectivity symmetric
node_connectivity = node_connectivity + node_connectivity';%This is the double

%%% node_connectivity %%%
Nn = Nx*Ny;

[node_y, node_x] = meshgrid(0:Ny-1,0:Nx-1);
[node_xy] = [reshape(node_x, numel(node_x),1) reshape(node_y, numel(node_y),1)];%All the node coordinate of the simulation
%The first row is the location in x direction, the second row is the location in y direction
%%% 'neighwithpositiveflux', 'PositiveFluxVector', 'link_Ttime' %%%
node_velocity = sparse(Nn,Nn);     % matrix for node connectivity where the value is velocity
link_Ttime_all = sparse(Nn,Nn);
residence_T = residence_T';%transmitive
w = 1;   % Index to track fracture
i = 1;   % Index to track node
b = 1;   % porosity/ width of the fracture

FLUX_edge = fx(:,2:end-1);%This is the FLUX in flow sulover fx  Ny*Nx
%%Txmat = zeros(Ny,Nx+1); 
FLUX_edge_trans = FLUX_edge';%This is the FLUX in flow sulover on the boundary
FLUX_edge_all = FLUX_edge_trans(:);%All the elment of the matrix%transform the matrix to a vector, the element is ranged by row
link_num = size(FLUX_edge(:),1);%Nx*Ny+1?? The last element is 1

for k = 1:Ny % N-1 : number of columns / 2  
    for j = 1: Nx-1 % calculate mean velocities for x velocity
        node_velocity(i,i+1) = FLUX_edge_all(w);%The flux in every node, I think it has excluded the boundary%The value in the first diag
        link_Ttime_all(i,i+1) = sign(FLUX_edge_all(w))*residence_T(i);%I think related to flow??%The value in the first diag
        link_Ttime_all(i+1,i) = sign(-FLUX_edge_all(w))*residence_T(i+1);%%The value in the negative first diag
        w= w+1;
        i = i + 1;
    end   
    i = i + 1;   
end

w = 1;   % Index to track fracture
i = 1;   % Index to track node
b = 1;   % porosity/ width of the fracture

FLUX_edge = fy(2:end-1,:);%This is the FLUX in flow sulover fx  Nx*Ny
FLUX_edge_trans = FLUX_edge';
FLUX_edge_all = FLUX_edge_trans(:);
link_num = size(FLUX_edge(:),1);%Ny??

for k = 1:Ny-1 % N-1 : number of columns / 2  
    for j = 1: Nx % calculate mean velocities for y velocity
        node_velocity(i,i+Nx) = -FLUX_edge_all(w);
        link_Ttime_all(i,i+Nx) = sign(-FLUX_edge_all(w))*residence_T(i);
        link_Ttime_all(i+Nx,i) = sign(FLUX_edge_all(w))*residence_T(i+Nx);
        w = w+1;
        i = i+1;
    end    
end
%%
node_velocity = node_velocity - node_velocity';%%I don't know

% The matrix N*3 where each row i represents the outflow neighbors of the node i
neighwithpositiveflux = sparse(Nn,4); 
% transition time for each link; LinkLength/FLUX
link_Ttime = sparse(Nn,4);            
% The matrix N*4 where each row i represents the outflow normalized flux of the link that connects the i with the outflow neighbors
PositiveFluxVector = sparse(Nn,5);    

for i = 1:Nn   
    if sum(find(node_velocity(i,:)>0)) > 0
       % The matrix N*3 where each row i represents the outflow neighbors of the node i
       neighwithpositiveflux(i,1:sum(node_velocity(i,:)>0)) = find(node_velocity(i,:)>0);
       link_Ttime(i,1:sum(node_velocity(i,:)>0)) = link_Ttime_all(i, (link_Ttime_all(i,:)>0));
       % The matrix N*4 where each row i represents the outflow normalized flux of the link that connects the i with the outflow neighbors
       PositiveFluxVector(i,1:sum(node_velocity(i,:)>0)+1) = [0 node_velocity(i, (node_velocity(i,:)>0))]; 
    end 
end

%fname_TPparam2 = sprintf('transport_param_gen.mat');
%save(fname_TPparam2, 'node_xy', 'Nx', 'Ny', 'neighwithpositiveflux', 'PositiveFluxVector', 'link_Ttime', 'node_connectivity');

end
