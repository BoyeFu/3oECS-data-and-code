%%
clear
%Two group of data
%All the unit of the stiffness is GPa, and the unit of pressure is 
%%
I = sqrt(-1);
Kf =2.25;%bulk modulus of water
yita = 1e-03;%viscosity
a=0.5e-02;%the radius of the crack
%Quartz
KdQ = 37;%Bulk modulus
mudQ = 44;%Shear modulus
%eQ = 0.001/8*12;%Crack density
eQ = 0.002;%Crack density
asp = 0.01;
phic = eQ;
eQQ = eQ/(8.*asp);
NNN = eQQ/(a.^3);
NNNN = NNN.*(3.42e-02).^3;
KdrQ = 26;%The bulk modulus of dry rock
mudrQ = 31;%The shear modulus of dry rock
PoQ = (3.*KdrQ-2.*mudrQ)./(2.*(3.*KdrQ+mudrQ));
kappa = 1e-15;%Permeability
phi = 0.1;%Porosity
arf =(KdQ-KdrQ)./KdQ;
%MQ1 = ((arf-phi)./KdQ+phi./Kf).^(-1);
MQ1 = KdQ/((1-KdrQ/KdQ)-phi*(1-KdQ/Kf));
%MQ = ((-KdrQ.*Kf+KdQ.*(Kf-Kf.*phi+KdQ.*phi))./(Kf.*KdQ.^2)).^(-1);
%MQ = Kf.*KdQ.^2./(-KdrQ.*Kf.*KdQ.*(Kf-phi.*Kf+KdQ.*phi)); 
MQ = ((arf-phi)./KdQ+phi./Kf).^(-1);
C1 = KdrQ+4/3.*mudrQ+arf.^2.*MQ1;
EXP = (-7:0.01:-3.0);
OMI = 10.^(EXP);
gQ = mudrQ./(KdrQ+4/3.*mudrQ);
CdrQ = KdrQ+4./3.*mudrQ;
KQBH = KdrQ+arf.^2.*MQ1;
CQBH = KQBH+4./3.*mudrQ;
CQ = KdQ+4./3.*mudQ;
k2 = sqrt((sqrt(-1).*OMI.*yita.*CQBH./kappa./MQ./CdrQ));
k2a = real((k2.*a));
HHB = CQBH.*ones(1,121);
rhoQ = 2.65/1000000;
rhof = 1.09/1000000;
rhoR = (1-phi).*rhoQ+phi.*rhof;
RAD001 = [0 pi/4 pi/2];
RAD010 = [0 pi/4 pi/2];
RAD020 = [0 pi/4 pi/2];
RAD050 = [0 pi/4 pi/2];
RAD100 = [0 pi/4 pi/2];
%%
%STADRD deviation = 0.0009 cm
STCRACK009 = [50.54	50.673	50.69	50.72	50.76];
STPRE009 = [0	9.08894046	17.85997043	24.97397999	31.86384677];
C22009 = (3.*KdQ+4.*mudQ)./(3+3.*KdQ.*eQ./STCRACK009+4.*mudQ.*eQ./STCRACK009);
CC22009 = (4.*mudQ+3.*KdQ.*(1+3./pi.*eQ.*mudQ./STCRACK009))./3./(1+9./4./pi.*eQ.*KdQ./STCRACK009);
ZCRACK009 = eQ./STCRACK009; 
ZCRACK009T = ZCRACK009./(1-PoQ./2);
C44009 = mudQ./(1+mudQ.*ZCRACK009T);%The shear modulus
deltaN009 = CdrQ.*ZCRACK009./(1+CdrQ.*ZCRACK009);
ZCRACK009S = ZCRACK009./(1+Kf.*deltaN009./(CQ.*phic.*(1-deltaN009)).*(1-Kf./KdQ).^(-1));
C11009H = (4.*mudrQ.*(1+mudrQ.*ZCRACK009S)+3.*KQBH.*(1+4.*mudrQ.*ZCRACK009S))./(3+3.*KQBH.*ZCRACK009S+4.*mudrQ.*ZCRACK009S);
%C11001H = CQBH.*ones(1,8);
C1100901 = (4.*mudrQ.*(1+mudrQ.*ZCRACK009)+3.*KdrQ.*(1+4.*mudrQ.*ZCRACK009))./(3+3.*KdrQ.*ZCRACK009+4.*mudrQ.*ZCRACK009);
C22009H = (3.*KQBH+4.*mudrQ)./(3+3.*KQBH.*ZCRACK009S+4.*mudrQ.*ZCRACK009S);
%C22001H = CQBH.*ones(1,8);
C2200901 = (3.*KdrQ+4.*mudrQ)./(3+3.*KdrQ.*ZCRACK009+4.*mudrQ.*ZCRACK009);
C12009H = (3.*KQBH-2.*mudrQ)./(3+3.*KQBH.*ZCRACK009S+4.*mudrQ.*ZCRACK009S);
%C12001H = (CQBH-2.*mudrQ).*ones(1,8);
C1200901 = (3.*KdrQ-2.*mudrQ)./(3+3.*KdrQ.*ZCRACK009+4.*mudrQ.*ZCRACK009);
C66009H = mudrQ./(1+mudrQ.*ZCRACK009T);
KX009 = KdrQ.*(3+4.*mudrQ.*ZCRACK009)./(3+3.*KdrQ.*ZCRACK009+4.*mudrQ.*ZCRACK009);
MX009 = ((1-KX009./KdQ-phi)/KdQ+phi./Kf).^(-1);
a1009 = 1-KX009./KdQ-(2.*mudrQ.*ZCRACK009)./(3+4.*mudrQ.*ZCRACK009).*KX009./KdQ;
a2009 = 1-KX009./KdQ+(6.*mudrQ.*ZCRACK009)./(3+4.*mudrQ.*ZCRACK009).*KX009./KdQ;
C110090 = CQBH-(((-2.* KdQ.* mudrQ.* (Kf - Kf.* phi + KdQ.* phi) + KdrQ .*(2 .*Kf .*mudrQ - 3 .*Kf.* KdQ .*phi + 3 .*KdQ.^2 .*phi)).^2.* ZCRACK009)./(3 .*(KdrQ.* Kf - KdQ.* (Kf - Kf .*phi + KdQ.* phi)) .*(-3 .*KdrQ.* KdQ.^2.* phi .*ZCRACK009 - KdQ.* (Kf - Kf.* phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK009) + KdrQ.* Kf.* (3 + 4.* mudrQ.* ZCRACK009 + 3.* KdQ.* (-1 + phi).* ZCRACK009))));
C220090 = C2200901+a2009.^2.*MX009;
C120090 = C1200901+a1009.*a2009.*MX009;
C660090 = mudrQ./(1+mudrQ.*ZCRACK009T);
%%
G009 = 2.*pi.*eQQ./a.*(C1-arf.*MQ1).^2.*sqrt(kappa./(yita.*C1.*MQ1.*CdrQ));
T009 = 2.*(C1-arf.*MQ1).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
%%
%Lower pressure
cita009L = (C22009H(1)-C220090(1)).^3./(2.*C22009H(1).*C220090(1).^2.*T009.*G009.^2);
tao009L = ((C22009H(1)-C220090(1))./C220090(1)./G009).^2;
fw0019L = (1-cita009L+cita009L.*sqrt(1-sqrt(-1).*OMI.*tao009L./cita009L.^2));
%%
%%
%C22
CCC22009L = C22009H(1)./(1+((C22009H(1)-C220090(1))./C220090(1))./fw0019L);
Q1C22009L = abs(imag(CCC22009L)./real(CCC22009L));
%%
%%
%C66
CCC66009L = C66009H(1)./(1+((C66009H(1)-C660090(1))./C660090(1))./fw0019L);
Q1C66009L = abs(imag(CCC66009L)./real(CCC66009L));
%%
%Medial Pressure
cita009M = (C22009H(3)-C220090(3)).^3./(2.*C22009H(3).*C220090(3).^2.*T009.*G009.^2);
tao009M = ((C22009H(3)-C220090(3))./C220090(3)./G009).^2;
%%
fw009M = (1-cita009M+cita009M.*sqrt(1-sqrt(-1).*OMI.*tao009M./cita009M.^2));
%%
%C22
CCZ22009M = 1./C22009H(3).*(1+((C22009H(3)-C220090(3))./C220090(3))./fw009M);
CCC22009M = 1./CCZ22009M;
Q1C22009M = abs(imag(CCC22009M)./real(CCC22009M));
%%
%C66
CCZ66009M = 1./C66009H(3).*(1+((C66009H(3)-C660090(3))./C660090(3))./fw009M);
CCC66009M = 1./CCZ66009M;
Q1C66009M = abs(imag(CCC66009M)./real(CCC66009M));
%%
%High Pressure
cita009H = (C22009H(5)-C220090(5)).^3./(2.*C22009H(5).*C220090(5).^2.*T009.*G009.^2);
tao009H = ((C22009H(5)-C220090(5))./C220090(5)./G009).^2;
%%
fw009H = (1-cita009H+cita009H.*sqrt(1-sqrt(-1).*OMI.*tao009H./cita009H.^2));
%%
%C22
CCZ22009H = 1./C22009H(5).*(1+((C22009H(5)-C220090(5))./C220090(5))./fw009H);
CCC22009H = 1./CCZ22009H;
Q1C22009H = abs(imag(CCC22009H)./real(CCC22009H));
%%
%C66
CCZ66009H = 1./C66009H(5).*(1+((C66009H(5)-C660090(5))./C660090(5))./fw009H);
CCC66009H = 1./CCZ66009H;
Q1C66009H = abs(imag(CCC66009H)./real(CCC66009H));
%%
%SATD deviation = 0.0012 cm
STCRACK012 = [50.69	50.78	50.78	50.83	50.85];
STPRE012 = [0	9.103707044	17.93566282	25.07798898	32.01510351];
C22012 = (3.*KdQ+4.*mudQ)./(3+3.*KdQ.*eQ./STCRACK012+4.*mudQ.*eQ./STCRACK012);
CC22012 = (4.*mudQ+3.*KdQ.*(1+3./pi.*eQ.*mudQ./STCRACK012))./3./(1+9./4./pi.*eQ.*KdQ./STCRACK012);
ZCRACK012 = eQ./STCRACK012; 
ZCRACK012T = ZCRACK012./(1-PoQ./2);
C44012 = mudQ./(1+mudQ.*ZCRACK012T);
deltaN012 = CdrQ.*ZCRACK012./(1+CdrQ.*ZCRACK012);
ZCRACK012S = ZCRACK012./(1+Kf.*deltaN012./(CQ.*phic.*(1-deltaN012)).*(1-Kf./KdQ).^(-1));
C11012H = (4.*mudrQ.*(1+mudrQ.*ZCRACK012S)+3.*KQBH.*(1+4.*mudrQ.*ZCRACK012S))./(3+3.*KQBH.*ZCRACK012S+4.*mudrQ.*ZCRACK012S);
C1101201 = (4.*mudrQ.*(1+mudrQ.*ZCRACK012)+3.*KdrQ.*(1+4.*mudrQ.*ZCRACK012))./(3+3.*KdrQ.*ZCRACK012+4.*mudrQ.*ZCRACK012);
C22012H = (3.*KQBH+4.*mudrQ)./(3+3.*KQBH.*ZCRACK012S+4.*mudrQ.*ZCRACK012S);
C2201201 = (3.*KdrQ+4.*mudrQ)./(3+3.*KdrQ.*ZCRACK012+4.*mudrQ.*ZCRACK012);
C12012H = (3.*KQBH-2.*mudrQ)./(3+3.*KQBH.*ZCRACK012S+4.*mudrQ.*ZCRACK012S);
C1201201 = (3.*KdrQ-2.*mudrQ)./(3+3.*KdrQ.*ZCRACK012+4.*mudrQ.*ZCRACK012);
C66012H = mudrQ./(1+mudrQ.*ZCRACK012T);
KX012 = KdrQ.*(3+4.*mudrQ.*ZCRACK012)./(3+3.*KdrQ.*ZCRACK012+4.*mudrQ.*ZCRACK012);
MX012 = ((1-KX012./KdQ-phi)/KdQ+phi./Kf).^(-1);
a1012 = 1-KX012./KdQ-(2.*mudrQ.*ZCRACK012)./(3+4.*mudrQ.*ZCRACK012).*KX012./KdQ;
a2012 = 1-KX012./KdQ+(6.*mudrQ.*ZCRACK012)./(3+4.*mudrQ.*ZCRACK012).*KX012./KdQ;
C110120 = CQBH-(((-2.* KdQ.* mudrQ.* (Kf - Kf.* phi + KdQ.* phi) + KdrQ .*(2 .*Kf .*mudrQ - 3 .*Kf.* KdQ .*phi + 3 .*KdQ.^2 .*phi)).^2.* ZCRACK012)./(3 .*(KdrQ.* Kf - KdQ.* (Kf - Kf .*phi + KdQ.* phi)) .*(-3 .*KdrQ.* KdQ.^2.* phi .*ZCRACK012 - KdQ.* (Kf - Kf.* phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK012) + KdrQ.* Kf.* (3 + 4.* mudrQ.* ZCRACK012 + 3.* KdQ.* (-1 + phi).* ZCRACK012))));
C220120 = C2201201+a2012.^2.*MX012;
C120120 = C1201201+a1012.*a2012.*MX012;
C660120 = mudrQ./(1+mudrQ.*ZCRACK012T);
%%
G012 = 2.*pi.*eQQ./a.*(C1-arf.*MQ1).^2.*sqrt(kappa./(yita.*C1.*MQ1.*CdrQ));
T012 = 2.*(C1-arf.*MQ1).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
%%
%Lower pressure
cita012L = (C22012H(1)-C220120(1)).^3./(2.*C22012H(1).*C220120(1).^2.*T012.*G012.^2);
tao012L = ((C22012H(1)-C220120(1))./C220120(1)./G012).^2;
%%
fw012L = (1-cita012L+cita012L.*sqrt(1-sqrt(-1).*OMI.*tao012L./cita012L.^2));
%%
%C22
CCZ22012L = 1./C22012H(1).*(1+((C22012H(1)-C220120(1))./C220120(1))./fw012L);
CCC22012L = 1./CCZ22012L;
Q1C22012L = abs(imag(CCC22012L)./real(CCC22012L));
%%
%C66
CCZ66012L = 1./C66012H(1).*(1+((C66012H(1)-C660120(1))./C660120(1))./fw012L);
CCC66012L = 1./CCZ66012L;
Q1C66012L = abs(imag(CCC66012L)./real(CCC66012L));
%%
%Medial Pressure
cita012M = (C22012H(3)-C220120(3)).^3./(2.*C22012H(3).*C220120(5).^2.*T012.*G012.^2);
tao012M = ((C22012H(3)-C220120(3))./C220120(5)./G012).^2;
%%
fw012M = (1-cita012M+cita012M.*sqrt(1-sqrt(-1).*OMI.*tao012M./cita012M.^2));
%C11
CCZ11012M = 1./C11012H(3).*(1+((C11012H(3)-C110120(3))./C110120(3))./fw012M);
CCC11012M = 1./CCZ11012M;
Q1C11012M = abs(imag(CCC11012M)./real(CCC11012M));
%%
%C22
CCZ22012M = 1./C22012H(3).*(1+((C22012H(3)-C220120(3))./C220120(3))./fw012M);
CCC22012M = 1./CCZ22012M;
Q1C22012M = abs(imag(CCC22012M)./real(CCC22012M));
%%
%C66
CCZ66012M = 1./C66012H(3).*(1+((C66012H(3)-C660120(3))./C660120(3))./fw012M);
CCC66012M = 1./CCZ66012M;
Q1C66012M = abs(imag(CCC66012M)./real(CCC66012M));
%%
%High Pressure
cita012H = (C22012H(5)-C220120(5)).^3./(2.*C22012H(5).*C220120(5).^2.*T012.*G012.^2);
tao012H = ((C22012H(5)-C220120(5))./C220120(5)./G012).^2;
%%
fw012H = (1-cita012H+cita012H.*sqrt(1-sqrt(-1).*OMI.*tao012H./cita012H.^2));
%%
%C22
CCZ22012H = 1./C22012H(5).*(1+((C22012H(5)-C220120(5))./C220120(5))./fw012H);
CCC22012H = 1./CCZ22012H;
Q1C22012H = abs(imag(CCC22012H)./real(CCC22012H));
%%
%C66
CCZ66012H = 1./C66012H(5).*(1+((C66012H(5)-C660120(5))./C660120(5))./fw012H);
CCC66012H = 1./CCZ66012H;
Q1C66012H = abs(imag(CCC66012H)./real(CCC66012H));
%%
%Standard deviation = 0.0015 cm
STCRACK015 =[50.72	50.72	50.85	50.93	51.13];
STPRE015 = [0	9.102487236	17.93733791	25.08983824	32.08769113];
C22015 = (3.*KdQ+4.*mudQ)./(3+3.*KdQ.*eQ./STCRACK015+4.*mudQ.*eQ./STCRACK015);
CC22015 = (4.*mudQ+3.*KdQ.*(1+3./pi.*eQ.*mudQ./STCRACK015))./3./(1+9./4./pi.*eQ.*KdQ./STCRACK015);
ZCRACK015 = eQ./STCRACK015; 
ZCRACK015T = ZCRACK015./(1-PoQ./2);
C44015 = mudQ./(1+mudQ.*ZCRACK015T);
deltaN015 = CdrQ.*ZCRACK015./(1+CdrQ.*ZCRACK015);
ZCRACK015S = ZCRACK015./(1+Kf.*deltaN015./(CQ.*phic.*(1-deltaN015)).*(1-Kf./KdQ).^(-1));
C11015H = (4.*mudrQ.*(1+mudrQ.*ZCRACK015S)+3.*KQBH.*(1+4.*mudrQ.*ZCRACK015S))./(3+3.*KQBH.*ZCRACK015S+4.*mudrQ.*ZCRACK015S);
C1101501 = (4.*mudrQ.*(1+mudrQ.*ZCRACK015)+3.*KdrQ.*(1+4.*mudrQ.*ZCRACK015))./(3+3.*KdrQ.*ZCRACK015+4.*mudrQ.*ZCRACK015);
C22015H = (3.*KQBH+4.*mudrQ)./(3+3.*KQBH.*ZCRACK015S+4.*mudrQ.*ZCRACK015S);
C2201501 = (3.*KdrQ+4.*mudrQ)./(3+3.*KdrQ.*ZCRACK015+4.*mudrQ.*ZCRACK015);
C12015H = (3.*KQBH-2.*mudrQ)./(3+3.*KQBH.*ZCRACK015S+4.*mudrQ.*ZCRACK015S);
C1201501 = (3.*KdrQ-2.*mudrQ)./(3+3.*KdrQ.*ZCRACK015+4.*mudrQ.*ZCRACK015);
C66015H = mudrQ./(1+mudrQ.*ZCRACK015T);
KX015 = KdrQ.*(3+4.*mudrQ.*ZCRACK015)./(3+3.*KdrQ.*ZCRACK015+4.*mudrQ.*ZCRACK015);
MX015 = ((1-KX015./KdQ-phi)/KdQ+phi./Kf).^(-1);
a1015 = 1-KX015./KdQ-(2.*mudrQ.*ZCRACK015)./(3+4.*mudrQ.*ZCRACK015).*KX015./KdQ;
a2015 = 1-KX015./KdQ+(6.*mudrQ.*ZCRACK015)./(3+4.*mudrQ.*ZCRACK015).*KX015./KdQ;
C110150 = CQBH-(((-2.* KdQ.* mudrQ.* (Kf - Kf.* phi + KdQ.* phi) + KdrQ .*(2 .*Kf .*mudrQ - 3 .*Kf.* KdQ .*phi + 3 .*KdQ.^2 .*phi)).^2.* ZCRACK015)./(3 .*(KdrQ.* Kf - KdQ.* (Kf - Kf .*phi + KdQ.* phi)) .*(-3 .*KdrQ.* KdQ.^2.* phi .*ZCRACK015 - KdQ.* (Kf - Kf.* phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK015) + KdrQ.* Kf.* (3 + 4.* mudrQ.* ZCRACK015 + 3.* KdQ.* (-1 + phi).* ZCRACK015))));
C220150 = C2201501+a2015.^2.*MX015;
C120150 = C1201501+a1015.*a2015.*MX015;
C660150 = mudrQ./(1+mudrQ.*ZCRACK015T);
%%
G015 = 2.*pi.*eQQ./a.*(C1-arf.*MQ1).^2.*sqrt(kappa./(yita.*C1.*MQ1.*CdrQ));
T015 = 2.*(C1-arf.*MQ1).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
%%
%Lower pressure
cita015L = (C22015H(1)-C220150(1)).^3./(2.*C22015H(1).*C220150(1).^2.*T015.*G015.^2);
tao015L = ((C22015H(1)-C220150(1))./C220150(1)./G015).^2;
%%
fw015L = (1-cita015L+cita015L.*sqrt(1-sqrt(-1).*OMI.*tao015L./cita015L.^2));
%%
%C22
CCZ22015L = 1./C22015H(1).*(1+((C22015H(1)-C220150(1))./C220150(1))./fw015L);
CCC22015L = 1./CCZ22015L;
Q1C22015L = abs(imag(CCC22015L)./real(CCC22015L));
%%
%C66
CCZ66015L = 1./C66015H(1).*(1+((C66015H(1)-C660150(1))./C660150(1))./fw015L);
CCC66015L = 1./CCZ66015L;
Q1C66015L = abs(imag(CCC66015L)./real(CCC66015L));
%%
%Medial Pressure
cita015M = (C22015H(3)-C220150(3)).^3./(2.*C22015H(3).*C220150(3).^2.*T015.*G015.^2);
tao015M = ((C22015H(3)-C220150(3))./C220150(3)./G015).^2;
%%
fw015M = (1-cita015M+cita015M.*sqrt(1-sqrt(-1).*OMI.*tao015M./cita015M.^2));
%%
%C22
CCZ22015M = 1./C22015H(3).*(1+((C22015H(3)-C220150(3))./C220150(3))./fw015M);
CCC22015M = 1./CCZ22015M;
Q1C22015M = abs(imag(CCC22015M)./real(CCC22015M));
%%
%C66
CCZ66015M = 1./C66015H(3).*(1+((C66015H(3)-C660150(3))./C660150(3))./fw015M);
CCC66015M = 1./CCZ66015M;
Q1C66015M = abs(imag(CCC66015M)./real(CCC66015M));
%%
%High Pressure
cita015H = (C22015H(5)-C220150(5)).^3./(2.*C22015H(5).*C220150(5).^2.*T015.*G015.^2);
tao015H = ((C22015H(5)-C220150(5))./C220150(5)./G015).^2;
%%
fw015H = (1-cita015H+cita015H.*sqrt(1-sqrt(-1).*OMI.*tao015H./cita015H.^2));
%%
%C22
CCZ22015H = 1./C22015H(5).*(1+((C22015H(5)-C220150(5))./C220150(5))./fw015H);
CCC22015H = 1./CCZ22015H;
Q1C22015H = abs(imag(CCC22015H)./real(CCC22015H));
%%
%C66
CCZ66015H = 1./C66015H(5).*(1+((C66015H(5)-C660150(5))./C660150(5))./fw015H);
CCC66015H = 1./CCZ66015H;
Q1C66015H = abs(imag(CCC66015H)./real(CCC66015H));
%%
%Standard deviation = 0.0018 cm
STCRACK018 = [50.7	50.85	50.99	51.04	51.2];
STPRE018 = [0	8.584253284	17.01640409	23.95504596	30.91381164];
C22018 = (3.*KdQ+4.*mudQ)./(3+3.*KdQ.*eQ./STCRACK018+4.*mudQ.*eQ./STCRACK018);
CC22018 = (4.*mudQ+3.*KdQ.*(1+3./pi.*eQ.*mudQ./STCRACK018))./3./(1+9./4./pi.*eQ.*KdQ./STCRACK018);
ZCRACK018 = eQ./STCRACK018; 
ZCRACK018T = ZCRACK018./(1-PoQ./2);
C44018 = mudQ./(1+mudQ.*ZCRACK018T);
deltaN018 = CdrQ.*ZCRACK018./(1+CdrQ.*ZCRACK018);
ZCRACK018S = ZCRACK018./(1+Kf.*deltaN018./(CQ.*phic.*(1-deltaN018)).*(1-Kf./KdQ).^(-1));
C11018H = (4.*mudrQ.*(1+mudrQ.*ZCRACK018S)+3.*KQBH.*(1+4.*mudrQ.*ZCRACK018S))./(3+3.*KQBH.*ZCRACK018S+4.*mudrQ.*ZCRACK018S);
C1101801 = (4.*mudrQ.*(1+mudrQ.*ZCRACK018)+3.*KdrQ.*(1+4.*mudrQ.*ZCRACK018))./(3+3.*KdrQ.*ZCRACK018+4.*mudrQ.*ZCRACK018);
C22018H = (3.*KQBH+4.*mudrQ)./(3+3.*KQBH.*ZCRACK018S+4.*mudrQ.*ZCRACK018S);
C2201801 = (3.*KdrQ+4.*mudrQ)./(3+3.*KdrQ.*ZCRACK018+4.*mudrQ.*ZCRACK018);
C12018H = (3.*KQBH-2.*mudrQ)./(3+3.*KQBH.*ZCRACK018S+4.*mudrQ.*ZCRACK018S);
C1201801 = (3.*KdrQ-2.*mudrQ)./(3+3.*KdrQ.*ZCRACK018+4.*mudrQ.*ZCRACK018);
C66018H = mudrQ./(1+mudrQ.*ZCRACK018T);
KX018 = KdrQ.*(3+4.*mudrQ.*ZCRACK018)./(3+3.*KdrQ.*ZCRACK018+4.*mudrQ.*ZCRACK018);
MX018 = ((1-KX018./KdQ-phi)/KdQ+phi./Kf).^(-1);
a1018 = 1-KX018./KdQ-(2.*mudrQ.*ZCRACK018)./(3+4.*mudrQ.*ZCRACK018).*KX018./KdQ;
a2018 = 1-KX018./KdQ+(6.*mudrQ.*ZCRACK018)./(3+4.*mudrQ.*ZCRACK018).*KX018./KdQ;
C110180 = CQBH-(((-2.* KdQ.* mudrQ.* (Kf - Kf.* phi + KdQ.* phi) + KdrQ .*(2 .*Kf .*mudrQ - 3 .*Kf.* KdQ .*phi + 3 .*KdQ.^2 .*phi)).^2.* ZCRACK018)./(3 .*(KdrQ.* Kf - KdQ.* (Kf - Kf .*phi + KdQ.* phi)) .*(-3 .*KdrQ.* KdQ.^2.* phi .*ZCRACK018 - KdQ.* (Kf - Kf.* phi + KdQ.* phi) .*(3 + 4.* mudrQ.* ZCRACK018) + KdrQ.* Kf.* (3 + 4.* mudrQ.* ZCRACK018 + 3.* KdQ.* (-1 + phi).* ZCRACK018))));
C220180 = C2201801+a2018.^2.*MX018;
C120180 = C1201801+a1018.*a2018.*MX018;
C660180 = mudrQ./(1+mudrQ.*ZCRACK018T);
%%
G018 = 2.*pi.*eQQ./a.*(C1-arf.*MQ1).^2.*sqrt(kappa./(yita.*C1.*MQ1.*CdrQ));
T018 = 2.*(C1-arf.*MQ1).^2.*(2-4.*arf.*gQ+3.*arf.^2.*gQ.^2).*a.^2.*eQQ.*yita./(15.*mudrQ.*gQ.*(1-gQ).^2.*C1.*CdrQ.*kappa);
%%
%Lower pressure
cita018L = (C22018H(1)-C220180(1)).^3./(2.*C22018H(1).*C220180(1).^2.*T018.*G018.^2);
tao018L = ((C22018H(1)-C220180(1))./C220180(1)./G018).^2;
%%
fw018L = (1-cita018L+cita018L.*sqrt(1-sqrt(-1).*OMI.*tao018L./cita018L.^2));
%%
%C22
CCZ22018L = 1./C22018H(1).*(1+((C22018H(1)-C220180(1))./C220180(1))./fw018L);
CCC22018L = 1./CCZ22018L;
Q1C22018L = abs(imag(CCC22018L)./real(CCC22018L));
%%
%C66
CCZ66018L = 1./C66018H(1).*(1+((C66018H(1)-C660180(1))./C660180(1))./fw018L);
CCC66018L = 1./CCZ66018L;
Q1C66018L = abs(imag(CCC66018L)./real(CCC66018L));
%%
%Medial Pressure
cita018M = (C22018H(3)-C220180(3)).^3./(2.*C22018H(3).*C220180(3).^2.*T018.*G018.^2);
tao018M = ((C22018H(3)-C220180(3))./C220180(3)./G018).^2;
%%
fw018M = (1-cita018M+cita018M.*sqrt(1-sqrt(-1).*OMI.*tao018M./cita018M.^2));
%%
%C22
CCZ22018M = 1./C22018H(3).*(1+((C22018H(3)-C220180(3))./C220180(3))./fw018M);
CCC22018M = 1./CCZ22018M;
Q1C22018M = abs(imag(CCC22018M)./real(CCC22018M));
%%
%C66
CCZ66018M = 1./C66018H(3).*(1+((C66018H(3)-C660180(3))./C660180(3))./fw018M);
CCC66018M = 1./CCZ66018M;
Q1C66018M = abs(imag(CCC66018M)./real(CCC66018M));
%%
%High Pressure
cita018H = (C22018H(5)-C220180(5)).^3./(2.*C22018H(5).*C220180(5).^2.*T018.*G018.^2);
tao018H = ((C22018H(5)-C220180(5))./C220180(5)./G018).^2;
%%
fw018H = (1-cita018H+cita018H.*sqrt(1-sqrt(-1).*OMI.*tao018H./cita018H.^2));
%%
%C22
CCZ22018H = 1./C22018H(5).*(1+((C22018H(5)-C220180(5))./C220180(5))./fw018H);
CCC22018H = 1./CCZ22018H;
Q1C22018H = abs(imag(CCC22018H)./real(CCC22018H));
%%
%C66
CCZ66018H = 1./C66018H(5).*(1+((C66018H(5)-C660180(5))./C660180(5))./fw018H);
CCC66018H = 1./CCZ66018H;
Q1C66018H = abs(imag(CCC66018H)./real(CCC66018H));

%%
%%
%%
%%
%Plot the figure
figure(1)
plot(STPRE009,C22009)
hold on
plot(STPRE012,C22012)
hold on
plot(STPRE015,C22015)
hold on
plot(STPRE018,C22018)
% hold on
% plot(STPRE100,C22100)
legend('SSD = 0.0009cm','SSD = 0.0012cm','SSD = 0.0015um','SSD = 0.0018cm')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
figure(11)
plot(STPRE009,CC22009)
hold on
plot(STPRE012,CC22012)
hold on
plot(STPRE015,CC22015)
hold on
plot(STPRE018,CC22018)
% hold on
% plot(STPRE100,CC22100)
legend('SSD = 0.0009cm','SSD = 0.0012cm','SSD = 0.0015um','SSD = 0.0018cm')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%%
%Caculate the third-order elastic constant
%Do linear fitting
PREEX = (1:1:30);%The Pressure for simulation
%Standard deviation = 0.0009 cm
TOE009 = polyfit(STPRE009,C22009,1);
C22009TO = polyval(TOE009,PREEX);
%Standard deviation = 0.0012 cm
TOE012 = polyfit(STPRE012,C22012,1);
C22012TO = polyval(TOE012,PREEX);
%Standard deviation = 0.0015 cm
TOE015 = polyfit(STPRE015,C22015,1);
C22015TO = polyval(TOE015,PREEX);
%Standard deviation = 0.0018 cm
TOE018 = polyfit(STPRE018,C22018,1);
C22018TO = polyval(TOE018,PREEX);
%%
%%
%Confining pressure
%Do linear fitting
%Standard deviation = 0.0009 cm
TOE009C = polyfit(STPRE009,CC22009,1);
C22009TOC = polyval(TOE009C,PREEX);
%Standard deviation = 0.0012 cm
TOE012C = polyfit(STPRE012,CC22012,1);
C22012TOC = polyval(TOE012C,PREEX);
%Standard deviation = 0.0015 cm
TOE015C = polyfit(STPRE015,CC22015,1);
C22015TOC = polyval(TOE015C,PREEX);
%Standard deviation = 0.0018 cm
TOE018C = polyfit(STPRE018,CC22018,1);
C22018TOC = polyval(TOE018C,PREEX);
%%
%plot the Figure
figure(2)
plot(PREEX,C22009TO)
hold on
plot(PREEX,C22012TO)
hold on
plot(PREEX,C22015TO)
hold on
plot(PREEX,C22018TO)
legend('SSD = 0.0009cm','SSD = 0.0012cm','SSD = 0.0015um','SSD = 0.0018cm')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%plot the Figure
figure(21)
plot(PREEX,C22009TOC)
hold on
plot(PREEX,C22012TOC)
hold on
plot(PREEX,C22015TOC)
hold on
plot(PREEX,C22018TOC)
legend('SSD = 0.0009cm','SSD = 0.0012cm','SSD = 0.0015um','SSD = 0.0018cm')
xlabel('Pressure (MPa)')
ylabel('Stiffness (GPa)')
%%
%%
%deal with the third-order elastic constant
AUTOL = [0.0009 0.0012 0.0015 0.0018];%SSD
TOEQA = 1000.*[TOE009(1) TOE012(1) TOE015(1) TOE018(1)];%Third-order elastic constant for quartz for axial stress
TOEQC = 1000.*[TOE009C(1) TOE012C(1) TOE015C(1) TOE018C(1)];%Third-order elastic constant for quartz for confining stress
% TOEYYA = 1000.*[TOEYY001(1) TOEYY010(1) TOEYY020(1) TOEYY050(1) TOEYY100(1)];%Third-order elastic constant for Yanyan for axial stress
% TOEYYC = 1000.*[TOEYY001C(1) TOEYY010C(1) TOEYY020C(1) TOEYY050C(1) TOEYY100C(1)];%Third-order elastic constant for Yanyan for confining stress
% TOEYYAS = 1000.*[TOEYYS001(1) TOEYYS010(1) TOEYYS020(1) TOEYYS050(1) TOEYYS100(1)];%Third-order elastic constant for Yanyan for axial stress
%%
figure(105)
plot(log10(k2a),real(CCC22009L))
hold on
plot(log10(k2a),real(CCC22009M))
hold on
plot(log10(k2a),real(CCC22009H))
legend('C22L','C22M','C22H')
xlabel('Frequency (Log(k2a))')
ylabel('Elastic Modulus (GPa)')
figure(106)
plot(log10(k2a),real(CCC66009L))
hold on
plot(log10(k2a),real(CCC66009M))
hold on
plot(log10(k2a),real(CCC66009H))
legend('C22L','C22M','C22H')
xlabel('Frequency (Log(k2a))')
ylabel('Elastic Modulus (GPa)')
%%
%%
%Plot the variation of compliance  of the fracture
figure(112)
plot(STPRE009,ZCRACK009)
hold on
plot(STPRE012,ZCRACK012)
hold on
plot(STPRE015,ZCRACK015)
hold on
plot(STPRE018,ZCRACK018)
% hold on
% plot(STPRE100,ZCRACK100)
legend('SSD  = 0.0009cm','SSD = 0.0012cm','SSD = 0.0015um','SSD = 0.0018cm')
xlabel('Pressure (MPa)')
ylabel('Compliance (GPa^-1)')
close all
figure(113)
plot(STPRE009,C220090)
hold on
plot(STPRE012,C220120)
hold on
plot(STPRE015,C220150)
hold on
plot(STPRE018,C220180)
legend('SSD  = 0.0009cm','SSD = 0.0012cm','SSD = 0.0015um','SSD = 0.0018cm')
xlabel('Pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(114)
plot(STPRE009,C660090)
hold on
plot(STPRE012,C660120)
hold on
plot(STPRE015,C660150)
hold on
plot(STPRE018,C660180)
legend('SSD  = 0.0009cm','SSD = 0.0012cm','SSD = 0.0015um','SSD = 0.0018cm')
xlabel('Pressure (MPa)')
ylabel('S-wave modulus (GPa)')
figure(115)
plot(STPRE009,C22009H)
hold on
plot(STPRE012,C22012H)
hold on
plot(STPRE015,C22015H)
hold on
plot(STPRE018,C22018H)
legend('SSD  = 0.0009cm','SSD = 0.0012cm','SSD = 0.0015um','SSD = 0.0018cm')
xlabel('Pressure (MPa)')
ylabel('P-wave modulus (GPa)')
figure(116)
plot(STPRE009,C66009H)
hold on
plot(STPRE012,C66012H)
hold on
plot(STPRE015,C66015H)
hold on
plot(STPRE018,C66018H)
legend('SSD  = 0.0009cm','SSD = 0.0012cm','SSD = 0.0015um','SSD = 0.0018cm')
xlabel('Pressure (MPa)')
ylabel('S-wave modulus (GPa)')
%%
%Caculate the third-order elastic constant
%Do linear fitting
%PREEX = (1:0.1:15);%The Pressure for simulation
%low frequency
%P-wave
%Standard deviation = 0.0009 cm
%High pressure
TOE0090HP = polyfit(STPRE009(3:5),C220090(3:5),1);
C220090TOHP = polyval(TOE0090HP,STPRE009);
COC220090HP = min(min(corrcoef(C220090, C220090TOHP)));
%Low pressure
TOE0090LP = polyfit(STPRE009(1:3),C220090(1:3),1);
C220090TOLP = polyval(TOE0090LP,STPRE009);
COC220090LP = min(min(corrcoef(C220090, C220090TOLP)));
%%
%Standard deviation = 0.0012 cm
%High pressure
TOE0120HP = polyfit(STPRE012(3:5),C220120(3:5),1);
C220120TOHP = polyval(TOE0120HP,STPRE012);
COC220120HP = min(min(corrcoef(C220120, C220120TOHP)));
%Low pressure
TOE0120LP = polyfit(STPRE012(1:3),C220120(1:3),1);
C220120TOLP = polyval(TOE0120LP,STPRE012);
COC220120LP = min(min(corrcoef(C220120, C220120TOLP)));
%%
%Standard deviation = 0.0015 cm
%High pressure
TOE0150HP = polyfit(STPRE015(3:5),C220150(3:5),1);
C220150TOHP = polyval(TOE0150HP,STPRE015);
COC220150HP = min(min(corrcoef(C220150, C220150TOHP)));
%Low pressure
TOE0150LP = polyfit(STPRE015(1:3),C220150(1:3),1);
C220150TOLP = polyval(TOE0150LP,STPRE015);
COC220150LP = min(min(corrcoef(C220150, C220150TOLP)));
%%
%Standard deviation = 0.0018 cm
%High pressure
TOE0180HP = polyfit(STPRE018(3:5),C220180(3:5),1);
C220180TOHP = polyval(TOE0180HP,STPRE018);
COC220180HP = min(min(corrcoef(C220180, C220180TOHP)));
%Low pressure
TOE0180LP = polyfit(STPRE018(1:3),C220180(1:3),1);
C220180TOLP = polyval(TOE0180LP,STPRE018);
COC220180LP = min(min(corrcoef(C220180, C220180TOLP)));
%%
%S-wave-Axial
%low frequency
%Standard deviation = 0.0009 cm
%High pressure
TOES0090HP = polyfit(STPRE009(3:5),C660090(3:5),1);
C660090TOHP = polyval(TOES0090HP,STPRE009);
COC66009HP = min(min(corrcoef(C660090, C660090TOHP)));
%Low pressure
TOES0090LP = polyfit(STPRE009(1:3),C660090(1:3),1);
C660090TOLP = polyval(TOES0090LP,STPRE009);
COC66009LP = min(min(corrcoef(C660090, C660090TOLP)));
%%
%Standard deviation = 0.0012 cm
%High pressure
TOES0120HP = polyfit(STPRE012(3:5),C660120(3:5),1);
C660120TOHP = polyval(TOES0120HP,STPRE012);
COC66012HP = min(min(corrcoef(C660120, C660120TOHP)));
%Low pressure
TOES0120LP = polyfit(STPRE012(1:3),C660120(1:3),1);
C660120TOLP = polyval(TOES0120LP,STPRE012);
COC66012LP = min(min(corrcoef(C660120, C660120TOLP)));
%%
%Standard deviation length = 0.0015 cm
%High pressure
TOES0150HP = polyfit(STPRE015(3:5),C660150(3:5),1);
C660150TOHP = polyval(TOES0150HP,STPRE015);
COC66015HP = min(min(corrcoef(C660150, C660150TOHP)));
%Low pressure
TOES0150LP = polyfit(STPRE015(1:3),C660150(1:3),1);
C660150TOLP = polyval(TOES0150LP,STPRE015);
COC66015LP = min(min(corrcoef(C660150, C660150TOLP)));
%%
%Standard deviation = 0.0018 cm
%High pressure
TOES0180HP = polyfit(STPRE018(3:5),C660180(3:5),1);
C660180TOHP = polyval(TOES0180HP,STPRE018);
COC66018HP = min(min(corrcoef(C660180, C660180TOHP)));
%Low pressure
TOES0180LP = polyfit(STPRE018(1:3),C660180(1:3),1);
C660180TOLP = polyval(TOES0180LP,STPRE018);
COC66018LP = min(min(corrcoef(C660180, C660180TOLP)));
%%
%High frequency
%P-wave
%Standard deviation = 0.0009 cm
%High pressure
TOE009HHP = polyfit(STPRE009(3:5),C22009H(3:5),1);
C22009HTOHP = polyval(TOE009HHP,STPRE009);
COC22009HHP = min(min(corrcoef(C22009H, C22009HTOHP)));
%Low pressure
TOE009HLP = polyfit(STPRE009(1:3),C22009H(1:3),1);
C22009HTOLP = polyval(TOE009HLP,STPRE009);
COC22009HLP = min(min(corrcoef(C22009H, C22009HTOLP)));
%%
%Standard deviation = 0.0012 cm
%High pressure
TOE012HHP = polyfit(STPRE012(3:5),C22012H(3:5),1);
C22012HTOHP = polyval(TOE012HHP,STPRE012);
COC22012HHP = min(min(corrcoef(C22012H, C22012HTOHP)));
%Low pressure
TOE012HLP = polyfit(STPRE012(1:3),C22012H(1:3),1);
C22012HTOLP = polyval(TOE012HLP,STPRE012);
COC22012HLP = min(min(corrcoef(C22012H, C22012HTOLP)));
%%
%Standard deviation = 0.0015 cm
%High pressure
TOE015HHP = polyfit(STPRE015(3:5),C22015H(3:5),1);
C22015HTOHP = polyval(TOE015HHP,STPRE015);
COC22015HHP = min(min(corrcoef(C22015H, C22015HTOHP)));
%Low pressure
TOE015HLP = polyfit(STPRE015(1:3),C22015H(1:3),1);
C22015HTOLP = polyval(TOE015HLP,STPRE015);
COC22015HLP = min(min(corrcoef(C22015H, C22015HTOLP)));
%%
%Standard deviation = 0.0018 cm
%High pressure
TOE018HHP = polyfit(STPRE018(3:5),C22018H(3:5),1);
C22018HTOHP = polyval(TOE018HHP,STPRE018);
COC22018HHP = min(min(corrcoef(C22018H, C22018HTOHP)));
%Low pressure
TOE018HLP = polyfit(STPRE018(1:3),C22018H(1:3),1);
C22018HTOLP = polyval(TOE018HLP,STPRE018);
COC22018HLP = min(min(corrcoef(C22018H, C22018HTOLP)));
%%
%S-wave-Axial
%low frequency
%Standard deviation = 0.0009 cm
%High pressure
TOES009HHP = polyfit(STPRE009(3:5),C66009H(3:5),1);
C66009HTOHP = polyval(TOES009HHP,STPRE009);
COC66009HHP = min(min(corrcoef(C66009H, C66009HTOHP)));
%Low pressure
TOES009HLP = polyfit(STPRE009(1:3),C66009H(1:3),1);
C66009HTOLP = polyval(TOES009HLP,STPRE009);
COC66009HLP = min(min(corrcoef(C66009H, C66009HTOLP)));
%%
%Standard deviation = 0.0012 cm
%High pressure
TOES012HHP = polyfit(STPRE012(3:5),C66012H(3:5),1);
C66012HTOHP = polyval(TOES012HHP,STPRE012);
COC66012HHP = min(min(corrcoef(C66012H, C66012HTOHP)));
%Low pressure
TOES012HLP = polyfit(STPRE012(1:3),C66012H(1:3),1);
C66012HTOLP = polyval(TOES012HLP,STPRE012);
COC66012HLP = min(min(corrcoef(C66012H, C66012HTOLP)));
%%
%Standard deviaion = 0.0015 cm
%High pressure
TOES015HHP = polyfit(STPRE015(3:5),C66015H(3:5),1);
C66015HTOHP = polyval(TOES015HHP,STPRE015);
COC66015HHP = min(min(corrcoef(C66015H, C66015HTOHP)));
%Low pressure
TOES015HLP = polyfit(STPRE015(1:3),C66015H(1:3),1);
C66015HTOLP = polyval(TOES015HLP,STPRE015);
COC66015HLP = min(min(corrcoef(C66015H, C66015HTOLP)));
%%
%Standard deviation = 0.0018 cm
%High pressure
TOES018HHP = polyfit(STPRE018(3:5),C66018H(3:5),1);
C66018HTOHP = polyval(TOES018HHP,STPRE018);
COC66018HHP = min(min(corrcoef(C66018H, C66018HTOHP)));
%Low pressure
TOES018HLP = polyfit(STPRE018(1:3),C66018H(1:3),1);
C66018HTOLP = polyval(TOES018HLP,STPRE018);
COC66018HLP = min(min(corrcoef(C66018H, C66018HTOLP)));
%%

%%

SD = [0.0009 0.0012 0.0015 0.0018];%Autocorrelation length
%Low pressure 0-40MPa
LP = [17 17 17 17];
%High pressure 50-90MPa
HP = [30 30 30 30];
%Pressure point
PP = [17 30];
[SSD,PPD] = meshgrid(SD,PP);
%High pressure
TOELFHP = 1000.*[TOE0090HP(1) TOE0120HP(1) TOE0150HP(1) TOE0180HP(1)];
TOEHFHP = 1000.*[TOE009HHP(1) TOE012HHP(1) TOE015HHP(1) TOE018HHP(1)];
TOESLFHP = 1000.*[TOES0090HP(1) TOES0120HP(1) TOES0150HP(1) TOES0180HP(1)];
TOESHFHP = 1000.*[TOES009HHP(1) TOES012HHP(1) TOES015HHP(1) TOES018HHP(1)];
%Low pressure
TOELFLP = 1000.*[TOE0090LP(1) TOE0120LP(1) TOE0150LP(1) TOE0180LP(1)];
TOEHFLP = 1000.*[TOE009HLP(1) TOE012HLP(1) TOE015HLP(1) TOE018HLP(1)];
TOESLFLP = 1000.*[TOES0090LP(1) TOES0120LP(1) TOES0150LP(1) TOES0180LP(1)];
TOESHFLP = 1000.*[TOES009HLP(1) TOES012HLP(1) TOES015HLP(1) TOES018HLP(1)];
%%
%Model the 3oECs
%Low frequency
TOELF = [TOELFLP
    TOELFHP];
TOESLF = [TOESLFLP
    TOESLFHP];
%%
%High frequency
TOEHF = [TOEHFLP
    TOEHFHP];
TOESHF = [TOESHFLP
    TOESHFHP];
%%
figure(117)
plot(SD,TOELFHP)
hold on
plot(SD,TOEHFHP)
legend('Low-frequency','High-frequency')
xlabel('SSD (cm)')
ylabel('3oECs')
figure(118)
plot(SD,TOESLFHP)
hold on
plot(SD,TOESHFHP)
legend('Low-frequency','High-frequency')
xlabel('SSD (cm)')
ylabel('3oECs')
%%
%close all
%deal with the dispersion and attenuation
figure(119)
plot(log10(k2a),real(CCC22009M))
hold on
plot(log10(k2a),real(CCC22012M))
hold on
plot(log10(k2a),real(CCC22015M))
hold on
plot(log10(k2a),real(CCC22018M))
% hold on
% plot(log10(k2a),real(CCC22100L))
legend('SSD = 0.0009cm','SSD = 0.0012cm','SSD = 0.0015cm','SSD = 0.0018cm')
%xlabel('log10(k2a)')
ylabel('P-wave modulus (GPa)')
%
figure(120)
plot(log10(k2a),log10(Q1C22009M))
hold on
plot(log10(k2a),log10(Q1C22012M))
hold on
plot(log10(k2a),log10(Q1C22015M))
hold on
plot(log10(k2a),log10(Q1C22018M))
% hold on
% plot(log10(k2a),log10(Q1C22100L))
legend('SSD = 0.0009cm','SSD = 0.0012cm','SSD = 0.0015cm','SSD = 0.0018cm')
%xlabel('log10(k2a)')
ylabel('Attenuation (Log)')
%%
%%
%the attenuation and dispersion for different surface
figure(125)
plot(log10(k2a),real(CCC22009L))
hold on
plot(log10(k2a),real(CCC22009M))
hold on
plot(log10(k2a),real(CCC22009H))
legend('Effective pressure 0MPa','Effective pressure 70MPa','Effective pressure 90MPa')
%xlabel('log10(k2a)')
ylabel('P-wave modulus (GPa)')
%
figure(126)
plot(log10(k2a),log10(Q1C22009L))
hold on
plot(log10(k2a),log10(Q1C22009M))
hold on
plot(log10(k2a),log10(Q1C22009H))
legend('Effective pressure 0MPa','Effective pressure 70MPa','Effective pressure 90MPa')
%xlabel('log10(k2a)')
ylabel('Attenuation (Log)')
%%
%the attenuation and dispersion for different surface
figure(127)
plot(log10(k2a),real(CCC22018L))
hold on
plot(log10(k2a),real(CCC22018M))
hold on
plot(log10(k2a),real(CCC22018H))
legend('Effective pressure 0MPa','Effective pressure 70MPa','Effective pressure 90MPa')
%xlabel('log10(k2a)')
ylabel('P-wave modulus (GPa)')
%
figure(128)
plot(log10(k2a),log10(Q1C22018L))
hold on
plot(log10(k2a),log10(Q1C22018M))
hold on
plot(log10(k2a),log10(Q1C22018H))
legend('Effective pressure 0MPa','Effective pressure 70MPa','Effective pressure 90MPa')
%xlabel('log10(k2a)')
ylabel('Attenuation (Log)')
%%
%%

%%
%the dispersion of third-order elastic constant
%low SD = 0.0009cm
cita009 = (C22009H-C220090).^3./(2.*C22009H.*(C220090.^2).*T009.*(G009.^2));
tao009 = ((C22009H-C220090)./(C220090.*G009)).^2;
fw009 = zeros(length(STCRACK009),length(OMI));
for i = 1:length(STCRACK009)
fw009(i,:) = (1-cita009(i)+cita009(i).*sqrt(1-I.*OMI.*tao009(i)./cita009(i).^2));
end
%%
%C22
CCC22009 = zeros(length(STCRACK009),length(OMI));
for i = 1:length(STCRACK009)
CCC22009(i,:) = C22009H(i)./(1+((C22009H(i)-C220090(i))./C220090(i))./fw009(i,:));
end
Q1C22009 = abs(imag(CCC22009)./real(CCC22009));
CC22009 = real(CCC22009);
TOE22009LP = zeros(1,length(OMI));
TOE22009HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE22009MLP = polyfit(STPRE009(1:3),CC22009(1:3,i),1);
TOE22009LP(i) = 1000.*TOE22009MLP(1);
TOE22009MHP = polyfit(STPRE009(3:5),CC22009(3:5,i),1);
TOE22009HP(i) = 1000.*TOE22009MHP(1);
end
%%
%C66
CCC66009 = zeros(length(STCRACK009),length(OMI));
for i = 1:length(STCRACK009)
CCC66009(i,:) = C66009H(i)./(1+((C66009H(i)-C660090(i))./C660090(i))./fw009(i,:));
end
Q1C66009 = abs(imag(CCC66009)./real(CCC66009));
CC66009 = real(CCC66009);
TOE66009LP = zeros(1,length(OMI));
TOE66009HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE66009MLP = polyfit(STPRE009(1:3),CC66009(1:3,i),1);
TOE66009LP(i) = 1000.*TOE66009MLP(1);
TOE66009MHP = polyfit(STPRE009(3:5),CC66009(3:5,i),1);
TOE66009HP(i) = 1000.*TOE66009MHP(1);
end
%%
%the dispersion of third-order elastic constant
%low SD = 0.0012cm
cita012 = (C22012H-C220120).^3./(2.*C22012H.*C220120.^2.*T012.*G012.^2);
tao012 = ((C22012H-C220120)./C220120./G012).^2;
fw012 = zeros(length(STCRACK012),length(OMI));
for i = 1:length(STCRACK012)
fw012(i,:) = (1-cita012(i)+cita012(i).*sqrt(1-sqrt(-1).*OMI.*tao012(i)./cita012(i).^2));
end
%%
%C22
CCC22012 = zeros(length(STCRACK012),length(OMI));
for i = 1:length(STCRACK012)
CCC22012(i,:) = C22012H(i)./(1+((C22012H(i)-C220120(i))./C220120(i))./fw012(i,:));
end
Q1C22012 = abs(imag(CCC22012)./real(CCC22012));
CC22012 = real(CCC22012);
TOE22012LP = zeros(1,length(OMI));
TOE22012HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE22012MLP = polyfit(STPRE012(1:3),CC22012(1:3,i),1);
TOE22012LP(i) = 1000.*TOE22012MLP(1);
TOE22012MHP = polyfit(STPRE012(3:5),CC22012(3:5,i),1);
TOE22012HP(i) = 1000.*TOE22012MHP(1);
end
%%
%C66
CCC66012 = zeros(length(STCRACK012),length(OMI));
for i = 1:length(STCRACK012)
CCC66012(i,:) = C66012H(i)./(1+((C66012H(i)-C660120(i))./C660120(i))./fw012(i,:));
end
Q1C66012 = abs(imag(CCC66012)./real(CCC66012));
CC66012 = real(CCC66012);
TOE66012LP = zeros(1,length(OMI));
TOE66012HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE66012MLP = polyfit(STPRE012(1:3),CC66012(1:3,i),1);
TOE66012LP(i) = 1000.*TOE66012MLP(1);
TOE66012MHP = polyfit(STPRE012(3:5),CC66012(3:5,i),1);
TOE66012HP(i) = 1000.*TOE66012MHP(1);
end
%%
%the dispersion of third-order elastic constant
%low SD = 0.0015cm
cita015 = (C22015H-C220150).^3./(2.*C22015H.*C220150.^2.*T015.*G015.^2);
tao015 = ((C22015H-C220150)./C220150./G015).^2;
fw015 = zeros(length(STCRACK015),length(OMI));
for i = 1:length(STCRACK015)
fw015(i,:) = (1-cita015(i)+cita015(i).*sqrt(1-sqrt(-1).*OMI.*tao015(i)./cita015(i).^2));
end
%%
%C22
CCC22015 = zeros(length(STCRACK015),length(OMI));
for i = 1:length(STCRACK015)
CCC22015(i,:) = C22015H(i)./(1+((C22015H(i)-C220150(i))./C220150(i))./fw015(i,:));
end
Q1C22015 = abs(imag(CCC22015)./real(CCC22015));
CC22015 = real(CCC22015);
TOE22015LP = zeros(1,length(OMI));
TOE22015HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE22015MLP = polyfit(STPRE015(1:3),CC22015(1:3,i),1);
TOE22015LP(i) = 1000.*TOE22015MLP(1);
TOE22015MHP = polyfit(STPRE015(3:5),CC22015(3:5,i),1);
TOE22015HP(i) = 1000.*TOE22015MHP(1);
end
%%
%C66
CCC66015 = zeros(length(STCRACK015),length(OMI));
for i = 1:length(STCRACK015)
CCC66015(i,:) = C66015H(i)./(1+((C66015H(i)-C660150(i))./C660150(i))./fw015(i,:));
end
Q1C66015 = abs(imag(CCC66015)./real(CCC66015));
CC66015 = real(CCC66015);
TOE66015LP = zeros(1,length(OMI));
TOE66015HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE66015MLP = polyfit(STPRE015(1:3),CC66015(1:3,i),1);
TOE66015LP(i) = 1000.*TOE66015MLP(1);
TOE66015MHP = polyfit(STPRE015(3:5),CC66015(3:5,i),1);
TOE66015HP(i) = 1000.*TOE66015MHP(1);
end
%%
%the dispersion of third-order elastic constant
%low SD = 0.0018cm
cita018 = (C22018H-C220180).^3./(2.*C22018H.*C220180.^2.*T018.*G018.^2);
tao018 = ((C22018H-C220180)./C220180./G018).^2;
fw018 = zeros(length(STCRACK018),length(OMI));
for i = 1:length(STCRACK018)
fw018(i,:) = (1-cita018(i)+cita018(i).*sqrt(1-sqrt(-1).*OMI.*tao018(i)./cita018(i).^2));
end
%%
%C22
CCC22018 = zeros(length(STCRACK018),length(OMI));
for i = 1:length(STCRACK018)
CCC22018(i,:) = C22018H(i)./(1+((C22018H(i)-C220180(i))./C220180(i))./fw018(i,:));
end
Q1C22018 = abs(imag(CCC22018)./real(CCC22018));
CC22018 = real(CCC22018);
TOE22018LP = zeros(1,length(OMI));
TOE22018HP = zeros(1,length(OMI));
for i = 1:length(OMI)
TOE22018MLP = polyfit(STPRE018(1:3),CC22018(1:3,i),1);
TOE22018LP(i) = 1000.*TOE22018MLP(1);
TOE22018MHP = polyfit(STPRE018(3:5),CC22018(3:5,i),1);
TOE22018HP(i) = 1000.*TOE22018MHP(1);
end

%%
%%
figure(130)
plot(log10(k2a),TOE22009LP)
hold on
plot(log10(k2a),TOE22012LP)
hold on
plot(log10(k2a),TOE22015LP)
hold on
plot(log10(k2a),TOE22018LP)
% hold on
% plot(log10(k2a),TOE22100)
legend('SSD = 0.0009cm','SSD = 0.0012cm','SSD = 0.0015cm','SSD = 0.0018cm')
ylabel('3oECs')
figure(1301)
plot(log10(k2a),TOE22009HP)
hold on
plot(log10(k2a),TOE22012HP)
hold on
plot(log10(k2a),TOE22015HP)
hold on
plot(log10(k2a),TOE22018HP)
legend('SSD = 0.0009cm','SSD = 0.0012cm','SSD = 0.0015cm','SSD = 0.0018cm')
ylabel('3oECs')
% 

figure(131)
plot(STPRE009,ZCRACK009)
hold on
plot(STPRE012,ZCRACK012)
hold on
plot(STPRE015,ZCRACK015)
hold on
plot(STPRE018,ZCRACK018)
legend('SSD = 0.0009cm','SSD = 0.0012cm','SSD = 0.0015cm','SSD = 0.0018cm')
xlabel('Pressure (MPa)')
ylabel('Complinace (GPa^-1)')

%%
%Plot the 3D variation of the 3oECs
figure(134)
mesh(SSD,PPD,TOELF)
hold on
mesh(SSD,PPD,TOEHF)
xlabel('SSD (cm)')
ylabel('Pressure (MPa)')
zlabel('3oECs')
figure(135)
mesh(SSD,PPD,TOESLF)
hold on
mesh(SSD,PPD,TOESHF)
xlabel('SSD (cm)')
ylabel('Pressure (MPa)')
zlabel('3oECs')